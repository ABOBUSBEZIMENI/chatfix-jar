package com.chatfix.mixin;

import com.chatfix.ChatFixLayout;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ChatComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatComponent.class)
public abstract class ChatComponentMixin {
	@Shadow
	public abstract int getWidth();

	@Shadow
	public abstract int getHeight();

	@Shadow
	public abstract double getScale();

	@Unique
	private float chatfix$chatPixels() {
		return (float) (this.getHeight() * this.getScale());
	}

	@Unique
	private float chatfix$widthPixels() {
		return (float) (this.getWidth() * this.getScale()) + 8f;
	}

	@Unique
	private float chatfix$ty() {
		int guiH = Minecraft.getInstance().getWindow().getGuiScaledHeight();
		return ChatFixLayout.ty(guiH, chatfix$chatPixels());
	}

	@Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIIZ)V", at = @At("HEAD"))
	private void chatfix$pre(GuiGraphics graphics, int tickCount, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
		Minecraft mc = Minecraft.getInstance();
		int guiW = mc.getWindow().getGuiScaledWidth();
		int guiH = mc.getWindow().getGuiScaledHeight();
		ChatFixLayout.update(guiW, guiH, chatfix$chatPixels(), chatfix$widthPixels());
		graphics.pose().pushMatrix();
		graphics.pose().translate(ChatFixLayout.tx(), ChatFixLayout.ty(guiH, chatfix$chatPixels()));
	}

	@Inject(method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIIZ)V", at = @At("RETURN"))
	private void chatfix$post(GuiGraphics graphics, int tickCount, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
		graphics.pose().popMatrix();
	}

	// Чтобы наведение/клик по тексту чата попадали в сдвинутые строки.
	// require = 0: если у метода другое имя в этой версии — мод всё равно запустится.
	@ModifyVariable(method = "screenToChatY", at = @At("HEAD"), argsOnly = true, require = 0)
	private double chatfix$fixMouseY(double y) {
		return y - chatfix$ty();
	}

	@ModifyVariable(method = "screenToChatX", at = @At("HEAD"), argsOnly = true, require = 0)
	private double chatfix$fixMouseX(double x) {
		return x - ChatFixLayout.tx();
	}
}
