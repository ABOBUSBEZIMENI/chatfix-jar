package com.chatfix.mixin;

import com.chatfix.ChatFixLayout;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ChatComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Цели указаны через имена классов intermediary (class_332 = GuiGraphics, class_327 = Font),
 * а имя метода — через "*", поэтому мод не зависит от файла refmap.
 * Обе возможные сигнатуры render() помечены require = 0: если одной нет — это не краш.
 */
@Mixin(ChatComponent.class)
public abstract class ChatComponentMixin {

	@Unique
	private float chatfix$chatPixels() {
		ChatComponent chat = (ChatComponent) (Object) this;
		return (float) (chat.getHeight() * chat.getScale());
	}

	@Unique
	private float chatfix$widthPixels() {
		ChatComponent chat = (ChatComponent) (Object) this;
		return (float) (chat.getWidth() * chat.getScale()) + 8f;
	}

	@Unique
	private void chatfix$begin(GuiGraphics graphics) {
		if (ChatFixLayout.enter()) {
			Minecraft mc = Minecraft.getInstance();
			int guiW = mc.getWindow().getGuiScaledWidth();
			int guiH = mc.getWindow().getGuiScaledHeight();
			float chatPx = chatfix$chatPixels();
			ChatFixLayout.update(guiW, guiH, chatPx, chatfix$widthPixels());
			graphics.pose().pushMatrix();
			graphics.pose().translate(ChatFixLayout.tx(), ChatFixLayout.ty(guiH, chatPx));
		}
	}

	@Unique
	private void chatfix$end(GuiGraphics graphics) {
		if (ChatFixLayout.exit()) {
			graphics.pose().popMatrix();
		}
	}

	// Вариант 1: render(GuiGraphics, int, int, int, boolean)
	@Inject(method = "*(Lnet/minecraft/class_332;IIIZ)V", at = @At("HEAD"), require = 0)
	private void chatfix$headA(GuiGraphics graphics, int a, int b, int c, boolean d, CallbackInfo ci) {
		chatfix$begin(graphics);
	}

	@Inject(method = "*(Lnet/minecraft/class_332;IIIZ)V", at = @At("RETURN"), require = 0)
	private void chatfix$tailA(GuiGraphics graphics, int a, int b, int c, boolean d, CallbackInfo ci) {
		chatfix$end(graphics);
	}

	// Вариант 2: render(GuiGraphics, Font, int, int, int, boolean, boolean)
	@Inject(method = "*(Lnet/minecraft/class_332;Lnet/minecraft/class_327;IIIZZ)V", at = @At("HEAD"), require = 0)
	private void chatfix$headB(GuiGraphics graphics, Font font, int a, int b, int c, boolean d, boolean e, CallbackInfo ci) {
		chatfix$begin(graphics);
	}

	@Inject(method = "*(Lnet/minecraft/class_332;Lnet/minecraft/class_327;IIIZZ)V", at = @At("RETURN"), require = 0)
	private void chatfix$tailB(GuiGraphics graphics, Font font, int a, int b, int c, boolean d, boolean e, CallbackInfo ci) {
		chatfix$end(graphics);
	}
}
