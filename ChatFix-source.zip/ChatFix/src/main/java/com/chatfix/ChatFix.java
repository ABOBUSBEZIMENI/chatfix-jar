package com.chatfix;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

public class ChatFix implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ChatFixConfig.load();

		// Основной способ — мышкой в открытом чате. Команды оставлены как запасной вариант.
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(ClientCommandManager.literal("chatfix")
				.then(ClientCommandManager.literal("top").executes(ctx -> setMode(ctx, "top")))
				.then(ClientCommandManager.literal("bottom").executes(ctx -> setMode(ctx, "bottom")))
				.then(ClientCommandManager.literal("margin")
					.then(ClientCommandManager.argument("pixels", IntegerArgumentType.integer(0, 200))
						.executes(ctx -> {
							ChatFixConfig.margin = IntegerArgumentType.getInteger(ctx, "pixels");
							ChatFixConfig.save();
							ctx.getSource().sendFeedback(Component.literal("ChatFix: отступ = " + ChatFixConfig.margin));
							return 1;
						})))));
	}

	private static int setMode(CommandContext<FabricClientCommandSource> ctx, String mode) {
		ChatFixConfig.mode = mode;
		ChatFixConfig.save();
		ctx.getSource().sendFeedback(Component.literal("ChatFix: чат теперь " + (mode.equals("top") ? "сверху" : "снизу")));
		return 1;
	}
}
