package com.chatfix;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import org.lwjgl.glfw.GLFW;

/**
 * Считает сдвиг чата и обрабатывает перетаскивание мышкой.
 * Пока открыт чат: левая кнопка на чате — тащить, средняя кнопка — переключить верх/низ.
 */
public final class ChatFixLayout {
	private static boolean wasLeft;
	private static boolean wasMiddle;
	private static boolean dragging;
	private static double grabMouseX;
	private static double grabMouseY;
	private static int grabX;
	private static int grabY;

	private ChatFixLayout() {
	}

	/** Сдвиг по X относительно ванильной позиции (пиксели GUI). */
	public static float tx() {
		return "custom".equals(ChatFixConfig.mode) ? ChatFixConfig.x : 0f;
	}

	/** Сдвиг по Y относительно ванильной позиции (пиксели GUI). */
	public static float ty(int guiH, float chatPx) {
		switch (ChatFixConfig.mode) {
			case "top":
				return -Math.max(0f, (guiH - 40f) - chatPx - ChatFixConfig.margin);
			case "custom":
				return ChatFixConfig.y - (guiH - 40f);
			default:
				return 0f;
		}
	}

	public static void update(int guiW, int guiH, float chatPx, float widthPx) {
		Minecraft mc = Minecraft.getInstance();
		if (!(mc.screen instanceof ChatScreen)) {
			dragging = false;
			wasLeft = false;
			wasMiddle = false;
			return;
		}
		long window = GLFW.glfwGetCurrentContext();
		if (window == 0L) {
			return;
		}

		double[] cx = new double[1];
		double[] cy = new double[1];
		GLFW.glfwGetCursorPos(window, cx, cy);
		int[] ww = new int[1];
		int[] wh = new int[1];
		GLFW.glfwGetWindowSize(window, ww, wh);
		double mx = cx[0] * guiW / Math.max(1, ww[0]);
		double my = cy[0] * guiH / Math.max(1, wh[0]);

		boolean left = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		boolean middle = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

		float tx = tx();
		float ty = ty(guiH, chatPx);
		float rectLeft = tx;
		float rectRight = tx + widthPx;
		float rectBottom = (guiH - 40f) + ty;
		float rectTop = rectBottom - chatPx;
		boolean inside = mx >= rectLeft && mx <= rectRight && my >= rectTop && my <= rectBottom;

		if (left && !wasLeft && inside) {
			dragging = true;
			ChatFixConfig.mode = "custom";
			ChatFixConfig.x = Math.round(tx);
			ChatFixConfig.y = Math.round(rectBottom);
			grabMouseX = mx;
			grabMouseY = my;
			grabX = ChatFixConfig.x;
			grabY = ChatFixConfig.y;
		}

		if (dragging) {
			if (left) {
				int maxX = Math.max(0, Math.round(guiW - widthPx));
				int minY = Math.round(chatPx);
				ChatFixConfig.x = clamp(grabX + (int) Math.round(mx - grabMouseX), 0, maxX);
				ChatFixConfig.y = clamp(grabY + (int) Math.round(my - grabMouseY), minY, guiH);
			} else {
				dragging = false;
				ChatFixConfig.save();
			}
		}

		if (middle && !wasMiddle && inside) {
			ChatFixConfig.mode = "top".equals(ChatFixConfig.mode) ? "bottom" : "top";
			ChatFixConfig.save();
		}

		wasLeft = left;
		wasMiddle = middle;
	}

	private static int clamp(int v, int min, int max) {
		return Math.max(min, Math.min(max, v));
	}
}
