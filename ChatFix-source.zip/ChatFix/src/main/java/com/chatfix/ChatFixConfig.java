package com.chatfix;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ChatFixConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("chatfix.json");

	/** "top", "bottom" или "custom" (после перетаскивания мышкой) */
	public static String mode = "top";
	/** Отступ чата от верхнего края в режиме top */
	public static int margin = 4;
	/** Режим custom: X левого края чата (пиксели GUI) */
	public static int x = 0;
	/** Режим custom: Y нижнего края чата (пиксели GUI) */
	public static int y = 200;

	private ChatFixConfig() {
	}

	public static void load() {
		if (!Files.exists(FILE)) {
			save();
			return;
		}
		try {
			JsonObject json = GSON.fromJson(Files.readString(FILE), JsonObject.class);
			if (json == null) {
				return;
			}
			if (json.has("mode")) {
				mode = json.get("mode").getAsString();
			}
			if (json.has("margin")) {
				margin = Math.max(0, json.get("margin").getAsInt());
			}
			if (json.has("x")) {
				x = json.get("x").getAsInt();
			}
			if (json.has("y")) {
				y = json.get("y").getAsInt();
			}
		} catch (Exception e) {
			System.err.println("[ChatFix] Не удалось прочитать конфиг: " + e);
		}
	}

	public static void save() {
		JsonObject json = new JsonObject();
		json.addProperty("mode", mode);
		json.addProperty("margin", margin);
		json.addProperty("x", x);
		json.addProperty("y", y);
		try {
			Files.createDirectories(FILE.getParent());
			Files.writeString(FILE, GSON.toJson(json));
		} catch (IOException e) {
			System.err.println("[ChatFix] Не удалось сохранить конфиг: " + e);
		}
	}
}
